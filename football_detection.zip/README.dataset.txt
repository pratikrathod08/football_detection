# symbol_detection > 2024-01-18 9:48pm
https://universe.roboflow.com/pratik1/symbol_detection-6vqmd

Provided by a Roboflow user
License: CC BY 4.0

